import React from "react";



function Frequently() {
  return ( 
    <section className="form">
    <div className="more">
    <div > 
          <br />
          <br />
          <br />
          <br />
        <h2>Subscribe for More Features</h2>
    </div>
    
    <div>
      <form action="" method="">
      <input type="email" name="name" id="" placeholder="Enter your email"> 
      </input>
        <button className="sumit" type="submit"><i class="fa fa-rocket"></i> Subscribe</button>
      </form>
        <h5>Please enter a value</h5>
    </div>
      </div>
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
    </section>
  );
}

export default Frequently;